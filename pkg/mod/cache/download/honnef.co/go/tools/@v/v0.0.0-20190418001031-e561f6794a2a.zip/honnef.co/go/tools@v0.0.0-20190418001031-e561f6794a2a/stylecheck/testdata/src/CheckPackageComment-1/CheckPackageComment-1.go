package pkg // MATCH "at least one file in a package should have a package comment"
