package pkg

import _ "CheckDeprecatedassist" // MATCH "Alas, it is deprecated."
