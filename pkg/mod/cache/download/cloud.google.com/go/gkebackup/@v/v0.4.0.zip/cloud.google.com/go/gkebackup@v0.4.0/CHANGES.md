# Changelog

## [0.4.0](https://github.com/googleapis/google-cloud-go/compare/gkebackup/v0.3.0...gkebackup/v0.4.0) (2023-01-04)


### Features

* **gkebackup:** Add REST client ([06a54a1](https://github.com/googleapis/google-cloud-go/commit/06a54a16a5866cce966547c51e203b9e09a25bc0))

## [0.3.0](https://github.com/googleapis/google-cloud-go/compare/gkebackup/v0.2.0...gkebackup/v0.3.0) (2022-11-03)


### Features

* **gkebackup:** rewrite signatures in terms of new location ([3c4b2b3](https://github.com/googleapis/google-cloud-go/commit/3c4b2b34565795537aac1661e6af2442437e34ad))

## [0.2.0](https://github.com/googleapis/google-cloud-go/compare/gkebackup/v0.1.0...gkebackup/v0.2.0) (2022-10-25)


### Features

* **gkebackup:** start generating stubs dir ([de2d180](https://github.com/googleapis/google-cloud-go/commit/de2d18066dc613b72f6f8db93ca60146dabcfdcc))

## 0.1.0 (2022-05-16)


### Features

* **gkebackup:** start generating apiv1 ([#6031](https://github.com/googleapis/google-cloud-go/issues/6031)) ([4816e84](https://github.com/googleapis/google-cloud-go/commit/4816e84076d62c0952eec0a7de80a230dc9074fe))
