# Changes

## [0.2.0](https://github.com/googleapis/google-cloud-go/compare/grafeas/v0.1.0...grafeas/v0.2.0) (2022-02-14)


### Features

* **grafeas:** add file for tracking version ([17b36ea](https://github.com/googleapis/google-cloud-go/commit/17b36ead42a96b1a01105122074e65164357519e))

## v0.1.0

This is the first tag to carve out grafeas as its own module. See
[Add a module to a multi-module repository](https://github.com/golang/go/wiki/Modules#is-it-possible-to-add-a-module-to-a-multi-module-repository).
