# Changes


## [1.2.0](https://github.com/googleapis/google-cloud-go/compare/optimization/v1.1.0...optimization/v1.2.0) (2022-11-03)


### Features

* **optimization:** rewrite signatures in terms of new location ([3c4b2b3](https://github.com/googleapis/google-cloud-go/commit/3c4b2b34565795537aac1661e6af2442437e34ad))

## [1.1.0](https://github.com/googleapis/google-cloud-go/compare/optimization/v1.0.0...optimization/v1.1.0) (2022-10-25)


### Features

* **optimization:** start generating stubs dir ([de2d180](https://github.com/googleapis/google-cloud-go/commit/de2d18066dc613b72f6f8db93ca60146dabcfdcc))

## [1.0.0](https://github.com/googleapis/google-cloud-go/compare/optimization/v0.1.0...optimization/v1.0.0) (2022-06-29)


### Features

* **optimization:** release 1.0.0 ([7678be5](https://github.com/googleapis/google-cloud-go/commit/7678be543d9130dcd8fc4147608a10b70faef44e))


### Miscellaneous Chores

* **optimization:** release 1.0.0 ([96b9b05](https://github.com/googleapis/google-cloud-go/commit/96b9b059e1c287bf7b287cdb8eb3f862f32a9610))

## 0.1.0 (2022-03-28)


### Features

* **optimization:** start generating apiv1 ([#5765](https://github.com/googleapis/google-cloud-go/issues/5765)) ([2de0229](https://github.com/googleapis/google-cloud-go/commit/2de02298d097d33a599b58fcf46a26a74253a79d))

## v0.1.0

- feat(optimization): start generating clients
