# Changes


## [1.3.1](https://github.com/googleapis/google-cloud-go/compare/optimization/v1.3.0...optimization/v1.3.1) (2023-02-14)


### Documentation

* **optimization:** Clarification for deprecated fields ([4623db8](https://github.com/googleapis/google-cloud-go/commit/4623db86fb70305278f6740999ecaee674506052))

## [1.3.0](https://github.com/googleapis/google-cloud-go/compare/optimization/v1.2.1...optimization/v1.3.0) (2023-01-04)


### Features

* **optimization:** Add REST client ([06a54a1](https://github.com/googleapis/google-cloud-go/commit/06a54a16a5866cce966547c51e203b9e09a25bc0))

## [1.2.1](https://github.com/googleapis/google-cloud-go/compare/optimization/v1.2.0...optimization/v1.2.1) (2022-12-01)


### Documentation

* **optimization:** fix minor docstring formatting ([7231644](https://github.com/googleapis/google-cloud-go/commit/7231644e71f05abc864924a0065b9ea22a489180))

## [1.2.0](https://github.com/googleapis/google-cloud-go/compare/optimization/v1.1.0...optimization/v1.2.0) (2022-11-03)


### Features

* **optimization:** rewrite signatures in terms of new location ([3c4b2b3](https://github.com/googleapis/google-cloud-go/commit/3c4b2b34565795537aac1661e6af2442437e34ad))

## [1.1.0](https://github.com/googleapis/google-cloud-go/compare/optimization/v1.0.0...optimization/v1.1.0) (2022-10-25)


### Features

* **optimization:** start generating stubs dir ([de2d180](https://github.com/googleapis/google-cloud-go/commit/de2d18066dc613b72f6f8db93ca60146dabcfdcc))

## [1.0.0](https://github.com/googleapis/google-cloud-go/compare/optimization/v0.1.0...optimization/v1.0.0) (2022-06-29)


### Features

* **optimization:** release 1.0.0 ([7678be5](https://github.com/googleapis/google-cloud-go/commit/7678be543d9130dcd8fc4147608a10b70faef44e))


### Miscellaneous Chores

* **optimization:** release 1.0.0 ([96b9b05](https://github.com/googleapis/google-cloud-go/commit/96b9b059e1c287bf7b287cdb8eb3f862f32a9610))

## 0.1.0 (2022-03-28)


### Features

* **optimization:** start generating apiv1 ([#5765](https://github.com/googleapis/google-cloud-go/issues/5765)) ([2de0229](https://github.com/googleapis/google-cloud-go/commit/2de02298d097d33a599b58fcf46a26a74253a79d))

## v0.1.0

- feat(optimization): start generating clients
