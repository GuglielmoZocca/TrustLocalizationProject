# Changelog

## [0.6.0](https://github.com/googleapis/google-cloud-go/compare/apikeys/v0.5.0...apikeys/v0.6.0) (2023-03-15)


### Features

* **apikeys:** Update iam and longrunning deps ([91a1f78](https://github.com/googleapis/google-cloud-go/commit/91a1f784a109da70f63b96414bba8a9b4254cddd))

## [0.5.0](https://github.com/googleapis/google-cloud-go/compare/apikeys/v0.4.0...apikeys/v0.5.0) (2023-02-17)


### Features

* **apikeys:** Migrate to new stubs ([a61ddcd](https://github.com/googleapis/google-cloud-go/commit/a61ddcd3041c7af4a15109dc4431f9b327c497fb))

## [0.4.0](https://github.com/googleapis/google-cloud-go/compare/apikeys/v0.3.0...apikeys/v0.4.0) (2023-02-16)


### Features

* **apikeys:** Start generating proto stubs ([970d763](https://github.com/googleapis/google-cloud-go/commit/970d763531b54b2bc75d7ff26a20b6e05150cab8))

## [0.3.0](https://github.com/googleapis/google-cloud-go/compare/apikeys/v0.2.0...apikeys/v0.3.0) (2023-01-04)


### Features

* **apikeys:** Add REST client ([06a54a1](https://github.com/googleapis/google-cloud-go/commit/06a54a16a5866cce966547c51e203b9e09a25bc0))

## [0.2.0](https://github.com/googleapis/google-cloud-go/compare/apikeys/v0.1.0...apikeys/v0.2.0) (2022-09-19)


### Features

* **apikeys:** enable REST transport for Python Preview clients ([ef2b0b1](https://github.com/googleapis/google-cloud-go/commit/ef2b0b1d4de9beb9005537ae48d7d8e1c0f23b98))

## 0.1.0 (2022-08-18)


### Features

* **apikeys:** start generating apiv2 ([#6524](https://github.com/googleapis/google-cloud-go/issues/6524)) ([8b140fa](https://github.com/googleapis/google-cloud-go/commit/8b140fa8a490d7f2e038ca8a776a1dfd46b74b4f))
