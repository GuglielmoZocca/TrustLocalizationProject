# Changelog

## [0.2.0](https://github.com/googleapis/google-cloud-go/compare/edgecontainer/v0.1.0...edgecontainer/v0.2.0) (2022-10-14)


### Features

* **edgecontainer:** temporally remove the version fields feat: add a field in cluster to describe whether the machine is disabled. fix: mark VPC project and service account as optional fields and add details for service account format ([de4e16a](https://github.com/googleapis/google-cloud-go/commit/de4e16a498354ea7271f5b396f7cb2bb430052aa))

## 0.1.0 (2022-09-20)


### Features

* **edgecontainer:** Start generating apiv1 ([#6694](https://github.com/googleapis/google-cloud-go/issues/6694)) ([6bc9b69](https://github.com/googleapis/google-cloud-go/commit/6bc9b69ca4dd910a9801f07bbc2b8abfdabe8628))

## Changes
