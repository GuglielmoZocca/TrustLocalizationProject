# Changelog

## 0.1.0 (2022-12-01)


### Features

* **vmwareengine:** Start generating apiv1 ([#7093](https://github.com/googleapis/google-cloud-go/issues/7093)) ([9cb00af](https://github.com/googleapis/google-cloud-go/commit/9cb00af1ad8ea1dcfd5b4a73cac75218460f9f6d))

## Changes
