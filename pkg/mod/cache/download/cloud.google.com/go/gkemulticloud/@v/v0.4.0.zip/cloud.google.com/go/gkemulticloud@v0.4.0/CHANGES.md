# Changelog

## [0.4.0](https://github.com/googleapis/google-cloud-go/compare/gkemulticloud/v0.3.0...gkemulticloud/v0.4.0) (2022-11-03)


### Features

* **gkemulticloud:** rewrite signatures in terms of new location ([3c4b2b3](https://github.com/googleapis/google-cloud-go/commit/3c4b2b34565795537aac1661e6af2442437e34ad))

## [0.3.0](https://github.com/googleapis/google-cloud-go/compare/gkemulticloud/v0.2.0...gkemulticloud/v0.3.0) (2022-10-25)


### Features

* **gkemulticloud:** start generating stubs dir ([de2d180](https://github.com/googleapis/google-cloud-go/commit/de2d18066dc613b72f6f8db93ca60146dabcfdcc))

## [0.2.0](https://github.com/googleapis/google-cloud-go/compare/gkemulticloud/v0.1.0...gkemulticloud/v0.2.0) (2022-05-24)


### Features

* **gkemulticloud:** Added support for other languages.Clients can now use this library to create gke clusters in cloud providers such as AWS and Azure ([6ef576e](https://github.com/googleapis/google-cloud-go/commit/6ef576e2d821d079e7b940cd5d49fe3ca64a7ba2))

## 0.1.0 (2022-05-16)


### Features

* **gkemulticloud:** start generating apiv1 ([#6036](https://github.com/googleapis/google-cloud-go/issues/6036)) ([dc2b168](https://github.com/googleapis/google-cloud-go/commit/dc2b168162ba358435c7191f9d02edaea17d19bb))
