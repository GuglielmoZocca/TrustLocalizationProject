# Generation

publish.csv was generated with `kimkyung@`'s ordering_key_verifier.

`schema` contains test data related to the schema feature.

`schema/us-states.proto` and `schema/us-states.avsc` are used to validate protobuf and avro schemas respectively. `schema/invalid.avsc` contains an invalid avro schema definition.

`schema/alaska.avro` and `schema/alaska.json` are messages for testing binary and json encoding of messages.
