# Feature: Minimal

## Scenario: minimalistic

  *  Given the minimalism
