## Feature: DataTables

### Scenario: minimalistic

* Given a simple data table 
  | foo | bar |
  | --- | --- |
  | boz | boo |
