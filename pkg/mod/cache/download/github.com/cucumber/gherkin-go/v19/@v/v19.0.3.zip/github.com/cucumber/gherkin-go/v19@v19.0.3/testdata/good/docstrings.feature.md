## Feature: DocString variations

### Scenario: minimalistic

* And a DocString with an implicitly escaped separator inside
````
```
````
