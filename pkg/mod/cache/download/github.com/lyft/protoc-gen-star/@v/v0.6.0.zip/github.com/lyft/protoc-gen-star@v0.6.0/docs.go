// Package pgs provides a library for building protoc plugins
package pgs
