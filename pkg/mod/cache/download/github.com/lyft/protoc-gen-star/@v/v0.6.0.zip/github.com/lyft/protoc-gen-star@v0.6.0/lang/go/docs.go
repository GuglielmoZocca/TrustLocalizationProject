// Package pgsgo contains Go-specific helpers for use with PG* based protoc-plugins
package pgsgo
