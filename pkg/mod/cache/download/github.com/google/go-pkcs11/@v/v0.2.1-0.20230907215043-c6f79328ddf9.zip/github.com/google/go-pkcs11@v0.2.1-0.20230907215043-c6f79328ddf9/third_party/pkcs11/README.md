PKCS #11 header files taken from the spec.

LICENSE is copied from https://www.oasis-open.org/policies-guidelines/ipr
(version published 07/31/2013).
