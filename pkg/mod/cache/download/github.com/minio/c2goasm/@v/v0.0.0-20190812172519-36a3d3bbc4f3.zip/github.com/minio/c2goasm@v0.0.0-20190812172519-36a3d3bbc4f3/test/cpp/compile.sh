c++ -O3 -mavx -mfma $1 $2
