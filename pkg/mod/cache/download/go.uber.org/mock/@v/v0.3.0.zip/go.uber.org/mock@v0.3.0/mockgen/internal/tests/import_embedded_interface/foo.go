package bugreport

type Foo interface {
	Bar() Baz
}
type Baz any
