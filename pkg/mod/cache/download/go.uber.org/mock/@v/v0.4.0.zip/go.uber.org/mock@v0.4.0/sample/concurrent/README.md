# Concurrent

This directory contains an example of executing mock calls concurrently.

To run the test,

```bash
go test -race go.uber.org/mock/sample/concurrent
```
