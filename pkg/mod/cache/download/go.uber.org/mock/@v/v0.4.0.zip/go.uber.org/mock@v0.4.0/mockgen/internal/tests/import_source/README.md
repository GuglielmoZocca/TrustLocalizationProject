# Import Source

Test the case where the generated code uses a type defined in the source package (in source mode). There are two test cases:

- the output is in a new package
- the output is in the same package as the input
