// Copyright the Hyperledger Fabric contributors. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

// Package chaincode contains the code necessary for chaincode to interact
// with a Hyperledger Fabric peer.
package chaincode
